package com.reto.reto3.repository.CRUD;

import org.springframework.data.repository.CrudRepository;

import com.reto.reto3.model.Category;

public interface CategoryCrudRepoInterfaz extends CrudRepository<Category,Integer>{
    
}
