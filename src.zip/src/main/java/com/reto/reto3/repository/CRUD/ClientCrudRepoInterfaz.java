package com.reto.reto3.repository.CRUD;

import org.springframework.data.repository.CrudRepository;

import com.reto.reto3.model.Client;

public interface ClientCrudRepoInterfaz extends CrudRepository<Client,Integer> {
    
}
