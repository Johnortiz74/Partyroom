package com.reto.reto3.repository.CRUD;

import org.springframework.data.repository.CrudRepository;

import com.reto.reto3.model.Admin;

public interface AdminCrudRepoInterfaz extends CrudRepository<Admin,Integer>{
    
}
