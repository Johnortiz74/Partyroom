package com.reto.reto3.repository;

public class AdminRepository {
    
}
